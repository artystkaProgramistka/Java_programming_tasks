package zad1;

public class Article {
    int id;
    double weight;

    public Article(int id, double weight) {
        this.id = id;
        this.weight = weight;
    }
}

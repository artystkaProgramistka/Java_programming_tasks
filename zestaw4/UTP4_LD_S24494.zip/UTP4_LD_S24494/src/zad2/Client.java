package zad2;

public class Client {
    String id, name;

    public Client(String id, String name) {
        this.id = id;
        this.name = name;
    }
}

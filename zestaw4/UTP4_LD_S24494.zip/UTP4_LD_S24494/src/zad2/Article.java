package zad2;

public class Article {
    String name;
    float price;

    public Article(String name, float price) {
        this.name = name;
        this.price = price;
    }
}

/**
 *
 *  @author Łęczycka Dominika S24494
 *
 */

package zad1;


public class Main {

  public static void main(String[] args) {
    Calc c = new Calc();
    String wynik = c.doCalc(args[0]);
    System.out.println(wynik);
  }

}
